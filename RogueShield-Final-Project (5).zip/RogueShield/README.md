# RogueShield

**Educational Rogue-Antivirus Behaviour Simulator**

RogueShield is a complete Windows desktop application written in Python that demonstrates how scareware / rogue antivirus programs behave. Every scan, threat, quarantine entry and pop-up is **completely simulated**. The project never modifies Windows security settings, the firewall, the network stack, or any real user files.

---

## Purpose

- Teach users what aggressive fake antivirus warnings look and feel like.
- Provide a safe, controllable environment for security-awareness training.
- Show the difference between legitimate security software and scareware tactics.

---

## Features

| Feature | Description |
|---------|-------------|
| **Fast random pop-ups** | Core demo. Random delay 0.2–1.5 s, random positions, varied titles/messages/colors. No artificial count limit while active. Instant STOP. |
| **Dashboard** | Protection status, threat counters, quick actions. |
| **Quick / Full Scan** | Animated progress, fictional threat detection, history. |
| **Quarantine & History** | Simulated only. |
| **Network / Firewall / Performance** | Placeholder pages explaining that nothing real is changed. |
| **RSHost.exe** | Independent background notifier that can keep running after the main window is closed. |
| **Startup integration** | Optional, visible entries in the Windows Startup folder / Run key. Fully removable via Windows Settings. |
| **Password protection** | Optional owner password for exit and startup changes. Does **not** block Task Manager. |
| **Demo files** | Creates `RogueShield-Demo` on the Desktop with harmless text reports. |
| **Installer** | Inno Setup script producing `RogueShield-Setup.exe`. |

---

## Project Structure

```
RogueShield/
├── src/
│   ├── rogueshield.py          # Main GUI application
│   ├── rshost.py               # Independent background notifier
│   ├── popup_manager.py        # Fast random pop-up engine
│   ├── scanner_simulator.py    # Simulated scans
│   ├── notification_manager.py # Toast-style notifications
│   ├── startup_manager.py      # Visible startup shortcuts
│   ├── security_manager.py     # Password dialogs
│   └── config_manager.py       # Local JSON settings
├── assets/icons/               # Placeholder for icons
├── installer/
│   └── RogueShield.iss         # Inno Setup 6 script
├── requirements.txt
├── BUILD_WINDOWS.bat           # Build executables + installer
├── RUN_FROM_SOURCE.bat         # Run without building
├── README.md
├── TESTING_GUIDE.md
├── SECURITY_AND_SCOPE.md
└── LICENSE.txt
```

---

## Quick Start (from source)

1. Install **Python 3.10+** (https://python.org) – tick “Add to PATH”.
2. Open a command prompt in the project root.
3. Double-click `RUN_FROM_SOURCE.bat` **or** run:
   ```
   python src\rogueshield.py
   ```
4. The main window appears and the pop-up demonstration starts automatically.
5. To stop pop-ups or exit you need the password: **`ItsMe2006!`**

To run the independent background notifier:

```
python src\rshost.py
```

---

## Building Windows Executables & Full Installer

**You must build on a Windows PC** (this environment cannot produce Windows .exe files).

**Full step-by-step guide:** see **`HOW_TO_BUILD_INSTALLER.md`**

Short version:

1. Install Python 3.10+ (Add to PATH).
2. Install [Inno Setup 6](https://jrsoftware.org/isdl.php).
3. Double-click **`BUILD_WINDOWS.bat`**.
4. When finished you will have:
   - `dist\RogueShield.exe`
   - `dist\RSHost.exe`
   - **`installer\Output\RogueShield-Setup.exe`** ← this is the complete installer

Run `RogueShield-Setup.exe` to install the whole application like any normal Windows program (Start Menu, optional desktop icon, optional startup, uninstaller).

---

## Pop-ups & Independence (important)

**Continuous pop-ups are owned only by RSHost**, not by the main window.

| Action | What happens to pop-ups |
|--------|-------------------------|
| Close main RogueShield window | Pop-ups **keep running** (RSHost still alive) |
| Kill main app in Task Manager | Pop-ups **keep running** |
| Restart Windows | RSHost is set to auto-start → pop-ups continue |
| Stop pop-ups | Open **RSHost** → Stop (password) **or** end `RSHost` in Task Manager |

Default password: **`ItsMe2006!`**

Closing the main app never stops the independent pop-up engine.

---

## Password

Default owner password is **`ItsMe2006!`**.

It protects:

- Stopping the pop-up simulation
- Normal application exit
- Enabling / disabling startup entries
- RSHost stop / exit

You can change it in **Settings → Change / Set Password**.

It does **not** protect against Task Manager, process kill, or Windows uninstall.

To reset if forgotten: delete the config file  
`%USERPROFILE%\.rogueshield\config.json`

---

## License

See `LICENSE.txt`. This software is provided for educational and research purposes only.

---

## Disclaimer

RogueShield is **not** antivirus software. It does not detect or remove malware.  
All displayed threats, scans and alerts are fictional.  
The authors accept no liability for misuse.
