# How to Build RogueShield.exe + Installer (RogueShield-Setup.exe)

This project is developed in a Linux environment, so **Windows executables cannot be built here**.  
You must build them once on a Windows PC. After that you get a normal installer.

---

## What you will get

After following these steps you will have:

| File | Description |
|------|-------------|
| `dist\RogueShield.exe` | Main application |
| `dist\RSHost.exe` | Background notifier |
| `installer\Output\RogueShield-Setup.exe` | **Full Windows installer** |

The installer installs both programs, creates Start Menu shortcuts, optional desktop icon, optional startup entries, and an uninstaller.

---

## Requirements (one-time)

1. **Windows 10 or 11**
2. **Python 3.10 or newer**  
   Download: https://www.python.org/downloads/  
   During install: **check “Add python.exe to PATH”**
3. **Inno Setup 6** (for the installer)  
   Download: https://jrsoftware.org/isdl.php  
   Install with default options.

---

## Build steps (takes ~2–5 minutes)

1. Extract `RogueShield-Final-Project.zip` anywhere (e.g. `C:\RogueShield`).
2. Double-click **`BUILD_WINDOWS.bat`**.
3. Wait until it finishes. You should see:

   ```
   Build complete
   Executables : dist\RogueShield.exe
                 dist\RSHost.exe
   Installer   : installer\Output\RogueShield-Setup.exe
   ```

4. Open the folder:
   ```
   installer\Output\
   ```
5. The file **`RogueShield-Setup.exe`** is your complete installer.

---

## Using the installer

1. Run `RogueShield-Setup.exe`.
2. Follow the wizard (it shows an educational disclaimer).
3. Choose install location (default is fine).
4. Optionally check:
   - Create desktop icon
   - Start RogueShield with Windows
   - Start RSHost with Windows
5. Finish → RogueShield is installed like a normal program.
6. Uninstall anytime from Windows Settings → Apps, or from the Start Menu.

---

## Default password

After install, stopping pop-ups or closing the app requires:

```
ItsMe2006!
```

You can change it inside the app under **Settings**.

---

## If something fails

| Problem | Solution |
|---------|----------|
| “Python is not in PATH” | Re-install Python and tick “Add to PATH”, or run from “Python” command prompt |
| PyInstaller error | Open a command prompt in the project folder and run: `pip install pyinstaller` then re-run the bat |
| No installer created | Install Inno Setup 6, then re-run `BUILD_WINDOWS.bat` |
| Antivirus blocks the .exe | This is common with PyInstaller apps. Add an exclusion or run from source |

---

## Alternative: run without building

If you only want to test quickly:

```bat
RUN_FROM_SOURCE.bat
```

or

```bat
python src\rogueshield.py
```

No installer is created this way, but the full application works.
