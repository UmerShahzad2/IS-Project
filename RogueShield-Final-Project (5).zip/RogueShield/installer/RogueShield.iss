; RogueShield – Inno Setup 6 Script
; Produces RogueShield-Setup.exe that installs both RogueShield.exe and RSHost.exe

#define MyAppName "RogueShield"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "RogueShield Educational Project"
#define MyAppURL "https://github.com/example/rogueshield"
#define MyAppExeName "RogueShield.exe"
#define MyHostExeName "RSHost.exe"

[Setup]
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
LicenseFile=..\LICENSE.txt
OutputDir=Output
OutputBaseFilename=RogueShield-Setup
SetupIconFile=
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}
InfoBeforeFile=

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "startup_rs"; Description: "Start RogueShield when Windows starts (visible Startup entry)"; GroupDescription: "Startup options:"; Flags: unchecked
Name: "startup_host"; Description: "Start RSHost when Windows starts (visible Startup entry)"; GroupDescription: "Startup options:"; Flags: unchecked

[Files]
; Main executables – expect them in ..\dist after running BUILD_WINDOWS.bat
Source: "..\dist\RogueShield.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\dist\RSHost.exe"; DestDir: "{app}"; Flags: ignoreversion
; Documentation
Source: "..\README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\SECURITY_AND_SCOPE.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\TESTING_GUIDE.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\RSHost (Background Notifier)"; Filename: "{app}\{#MyHostExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch RogueShield"; Flags: nowait postinstall skipifsilent

[Registry]
; Optional visible startup entries via Run key (user can still disable in Settings → Apps → Startup)
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "RogueShield"; ValueData: """{app}\{#MyAppExeName}"""; Flags: uninsdeletevalue; Tasks: startup_rs
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "RSHost"; ValueData: """{app}\{#MyHostExeName}"""; Flags: uninsdeletevalue; Tasks: startup_host

[Code]
function InitializeSetup(): Boolean;
begin
  Result := True;
  MsgBox('RogueShield is an EDUCATIONAL simulator of rogue-antivirus behaviour.' + #13#10 + #13#10 +
         'All scans, threats and pop-ups are simulated.' + #13#10 +
         'No real system security settings or user files are modified.' + #13#10 + #13#10 +
         'Use responsibly for security awareness training only.',
         mbInformation, MB_OK);
end;
