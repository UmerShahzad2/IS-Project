# RogueShield – Testing Guide

This document describes how to verify the project.  
Because the development environment may not be Windows, some tests are source-level only.

---

## 1. Python Syntax & Import Check

From the project root:

```bash
python -m py_compile src/config_manager.py
python -m py_compile src/security_manager.py
python -m py_compile src/startup_manager.py
python -m py_compile src/popup_manager.py
python -m py_compile src/scanner_simulator.py
python -m py_compile src/notification_manager.py
python -m py_compile src/rogueshield.py
python -m py_compile src/rshost.py
```

All files should compile without error.

---

## 2. GUI Startup (source)

```bash
python src/rogueshield.py
```

Expected:

- Dark-themed window titled “RogueShield – Educational Security Simulator”.
- Sidebar navigation works.
- Red **STOP POP-UPS** button is visible in the top bar.
- After ~0.6 s the pop-up simulation starts automatically.

---

## 3. Fast Random Pop-up System (highest priority)

| Test | Expected result |
|------|-----------------|
| Delay between pop-ups | Random, roughly 0.2–1.5 seconds |
| Position | Random locations across the screen |
| Content | Different titles, messages, colours / severity |
| Burst | Occasionally 2–4 pop-ups appear in rapid succession |
| No artificial limit | Pop-ups continue for as long as the simulation is active |
| STOP button | Immediately cancels scheduled events and closes existing pop-ups |
| CPU / memory | No runaway threads; after STOP the process is quiet |

---

## 4. Scanner Simulation

1. Open **Quick Scan** or **Full System Scan**.
2. Click **Start Simulation**.
3. Progress bar advances; status text updates.
4. On completion a fictional threat list appears and is added to Quarantine / History.

Cancel mid-scan works.

---

## 5. RSHost Independent Operation

```bash
python src/rshost.py
```

- Own window appears.
- Can start / stop its own notification stream.
- Closing the main RogueShield window does **not** kill RSHost if it was started separately.
- Exit / STOP buttons cleanly terminate its activity.

---

## 6. Startup Entries

1. Open **Settings**.
2. Toggle the two startup checkboxes (password may be required).
3. On Windows, verify shortcuts appear in the Startup folder or under  
   `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`.
4. Disable again; entries are removed.
5. Entries remain visible and removable via Windows Settings → Apps → Startup.

---

## 7. Password Protection

1. Settings → Change / Set Password.
2. Set a password.
3. Attempt to close the main window → password prompt appears.
4. Wrong password → exit cancelled.
5. Correct password → application closes.
6. To reset: delete `%USERPROFILE%\.rogueshield\config.json`.

---

## 8. Demo Files

After first launch a folder `RogueShield-Demo` is created on the Desktop containing:

- Threat_Report.txt
- Security_Alert.txt
- Scan_Result.txt
- System_Report.txt

All contain only fictional text. No encryption or deletion of real files occurs.

---

## 9. Installer Configuration

- Open `installer/RogueShield.iss` in Inno Setup 6.
- After building the two executables with `BUILD_WINDOWS.bat`, compile the script.
- The resulting `RogueShield-Setup.exe` installs both programs, creates Start Menu shortcuts, and offers optional startup tasks.
- Uninstall removes the files and the Run-key entries created by the installer.

---

## 10. ZIP Integrity

The final deliverable `RogueShield-Final-Project.zip` must contain the complete tree:

```
RogueShield/
  src/ (all .py files)
  assets/
  installer/
  requirements.txt
  BUILD_WINDOWS.bat
  RUN_FROM_SOURCE.bat
  README.md
  TESTING_GUIDE.md
  SECURITY_AND_SCOPE.md
  LICENSE.txt
```

Extract and verify that `RUN_FROM_SOURCE.bat` still launches the application.

---

## Environment Notes

- This project was developed and syntax-checked in a Linux-based CI/sandbox environment.
- Full Windows GUI, pop-up positioning, Startup folder, and Inno Setup tests require a real Windows machine.
- All simulated behaviour is intentionally non-destructive.
