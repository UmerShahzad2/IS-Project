Place application icons (e.g. .ico files) here if desired.
PyInstaller can pick them up with the --icon flag.
Currently the build script does not embed a custom icon.
