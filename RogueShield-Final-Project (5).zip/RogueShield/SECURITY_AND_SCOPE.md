# RogueShield – Security & Scope Statement

## What this project is

RogueShield is an **educational simulator** of rogue-antivirus (scareware) behaviour.  
It is intended for security-awareness training, classroom demonstration, and research into social-engineering tactics used by fake antivirus products.

## What this project is NOT

- It is **not** antivirus or anti-malware software.
- It does **not** detect, quarantine, or remove real threats.
- It does **not** improve the security of the host system.

## Guarantees of non-interference

The following actions are **never** performed by RogueShield or RSHost:

| Action | Status |
|--------|--------|
| Modify Windows Firewall rules | Not done |
| Change network configuration | Not done |
| Write to or delete arbitrary user files | Not done |
| Encrypt any files | Not done |
| Install browser extensions or change homepage | Not done |
| Disable real antivirus / Windows Defender | Not done |
| Create hidden scheduled tasks or services | Not done |
| Hide from Task Manager | Not done |
| Prevent process termination | Not done |
| Self-reinstall after uninstall | Not done |

All “threats”, scan results, quarantine entries and notifications are generated from static lists of fictional strings.

## Persistence

Startup integration uses only the standard, user-visible mechanisms:

- Shortcuts in the current user’s Startup folder, **or**
- Values under `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`

Both are listed in Windows Settings → Apps → Startup and can be disabled or removed by the user or by the application’s own Settings page.  
No stealth techniques are used.

## Password protection

An optional owner password can protect:

- Normal exit of the main window
- Changes to the startup checkboxes

The password does **not** prevent:

- Ending the process via Task Manager or `taskkill`
- Uninstalling the software
- Deleting the configuration file

## Demo files

On first run the application may create a folder `RogueShield-Demo` on the Desktop containing a few plain-text files with fictional reports.  
These files are ordinary text and can be deleted by the user at any time.  
No other locations are written to except the small JSON config under `%USERPROFILE%\.rogueshield\`.

## Responsible use

- Use only on systems you own or have explicit permission to use for training.
- Do not distribute the compiled binaries as real antivirus products.
- Do not use the pop-up engine to harass or alarm users who have not consented to a demonstration.
- Always make the educational nature of the tool clear to participants.

## Reporting issues

If you discover any behaviour that appears to modify real system state outside the documented scope, please treat it as a bug and report it so it can be corrected.
