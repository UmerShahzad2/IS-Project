@echo off
REM ============================================================
REM  RogueShield – Windows Build Script
REM  Creates:
REM    dist\RogueShield.exe
REM    dist\RSHost.exe
REM    installer\Output\RogueShield-Setup.exe  (if Inno Setup 6 is installed)
REM ============================================================

setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo.
echo  ========================================
echo   RogueShield Build Script
echo  ========================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not in PATH.
    echo         Install Python 3.10+ from https://www.python.org
    echo         and make sure "Add python.exe to PATH" is checked.
    pause
    exit /b 1
)

echo [1/5] Creating virtual environment...
if not exist ".venv" (
    python -m venv .venv
)
call .venv\Scripts\activate.bat

echo [2/5] Installing dependencies...
python -m pip install --upgrade pip >nul
pip install -r requirements.txt
pip install pyinstaller

echo.
echo [3/5] Building RogueShield.exe ...
pyinstaller --noconfirm --onefile --windowed ^
    --name RogueShield ^
    --distpath dist ^
    --workpath build ^
    --specpath build ^
    --clean ^
    src\rogueshield.py

if errorlevel 1 (
    echo [ERROR] Failed to build RogueShield.exe
    pause
    exit /b 1
)
echo       OK - dist\RogueShield.exe

echo.
echo [4/5] Building RSHost.exe ...
pyinstaller --noconfirm --onefile --windowed ^
    --name RSHost ^
    --distpath dist ^
    --workpath build ^
    --specpath build ^
    --clean ^
    src\rshost.py

if errorlevel 1 (
    echo [ERROR] Failed to build RSHost.exe
    pause
    exit /b 1
)
echo       OK - dist\RSHost.exe

echo.
echo [5/5] Building installer (Inno Setup)...
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" set "ISCC=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if exist "C:\Program Files\Inno Setup 6\ISCC.exe" set "ISCC=C:\Program Files\Inno Setup 6\ISCC.exe"

if defined ISCC (
    "%ISCC%" "installer\RogueShield.iss"
    if errorlevel 1 (
        echo [WARN] Inno Setup compilation failed.
        echo        Executables are still available in dist\
    ) else (
        echo       OK - installer\Output\RogueShield-Setup.exe
    )
) else (
    echo [INFO] Inno Setup 6 not found – skipping installer.
    echo        Download: https://jrsoftware.org/isdl.php
    echo        Install it, then run this script again to get RogueShield-Setup.exe
)

echo.
echo  ========================================
echo   BUILD FINISHED
echo  ========================================
echo.
echo   Main app     : dist\RogueShield.exe
echo   Background   : dist\RSHost.exe
echo   Installer    : installer\Output\RogueShield-Setup.exe
echo.
echo   Default password to stop pop-ups / exit : ItsMe2006!
echo.
echo   See HOW_TO_BUILD_INSTALLER.md for details.
echo.
pause
