"""
RogueShield - Configuration Manager
Handles application settings, password, and persistence of preferences.
All data is stored locally in a simple JSON config file.
"""

import json
import os
import hashlib
from pathlib import Path

# Default config location (user profile for real installs)
DEFAULT_CONFIG_DIR = Path.home() / ".rogueshield"
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.json"

# Default owner password is "ItsMe2006!"
# Users can change it later in Settings.
_DEFAULT_PASSWORD = "ItsMe2006!"
_DEFAULT_PASSWORD_HASH = hashlib.sha256(_DEFAULT_PASSWORD.encode("utf-8")).hexdigest()

DEFAULT_CONFIG = {
    "owner_password_hash": _DEFAULT_PASSWORD_HASH,  # Default: ItsMe2006!
    "startup_rogueshield": False,
    "startup_rshost": False,
    "popup_enabled": True,
    "scan_history": [],
    "quarantine_list": [],
    "theme": "dark",
    "window_geometry": "1100x700",
    "first_run": True,
}


class ConfigManager:
    def __init__(self, config_path: Path = None):
        self.config_path = Path(config_path) if config_path else DEFAULT_CONFIG_FILE
        self.config = DEFAULT_CONFIG.copy()
        self._ensure_dir()
        self.load()

    def _ensure_dir(self):
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

    def load(self):
        if self.config_path.exists():
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.config.update(data)
            except (json.JSONDecodeError, OSError):
                self.config = DEFAULT_CONFIG.copy()
        else:
            self.save()

        # Ensure a password is always set (default: ItsMe2006!)
        if not self.config.get("owner_password_hash"):
            self.config["owner_password_hash"] = _DEFAULT_PASSWORD_HASH
            self.save()

    def save(self):
        self._ensure_dir()
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=2)
        except OSError:
            pass

    def get(self, key, default=None):
        return self.config.get(key, default)

    def set(self, key, value):
        self.config[key] = value
        self.save()

    def set_password(self, plain_password: str):
        """Store SHA-256 hash of the password."""
        if not plain_password:
            self.config["owner_password_hash"] = ""
        else:
            h = hashlib.sha256(plain_password.encode("utf-8")).hexdigest()
            self.config["owner_password_hash"] = h
        self.save()

    def check_password(self, plain_password: str) -> bool:
        stored = self.config.get("owner_password_hash", "")
        if not stored:
            # No password set – accept any / treat as unlocked
            return True
        h = hashlib.sha256(plain_password.encode("utf-8")).hexdigest()
        return h == stored

    def has_password(self) -> bool:
        return bool(self.config.get("owner_password_hash", ""))

    def add_scan_history(self, entry: dict):
        history = self.config.get("scan_history", [])
        history.insert(0, entry)
        # Keep last 50 entries
        self.config["scan_history"] = history[:50]
        self.save()

    def add_quarantine(self, item: dict):
        q = self.config.get("quarantine_list", [])
        q.append(item)
        self.config["quarantine_list"] = q
        self.save()

    def clear_quarantine(self):
        self.config["quarantine_list"] = []
        self.save()
