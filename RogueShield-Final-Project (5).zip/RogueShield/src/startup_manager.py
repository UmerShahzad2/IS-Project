"""
RogueShield - Startup Manager
Creates / removes normal, visible Windows startup entries via the
user's Startup folder (shell:startup). No stealth, no hidden tasks.
"""

import os
import sys
import shutil
from pathlib import Path


def _get_startup_folder() -> Path:
    """Return the current user's Startup folder path."""
    # %APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
    appdata = os.environ.get("APPDATA")
    if not appdata:
        # Fallback for non-Windows / testing
        return Path.home() / "AppData" / "Roaming" / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"


def _create_shortcut(target_exe: Path, shortcut_name: str, working_dir: Path = None) -> bool:
    """
    Create a .lnk shortcut in the Startup folder.
    On non-Windows we just create a placeholder text file for demo purposes.
    """
    startup = _get_startup_folder()
    startup.mkdir(parents=True, exist_ok=True)
    link_path = startup / f"{shortcut_name}.lnk"

    if sys.platform != "win32":
        # Demo / Linux: write a marker file
        marker = startup / f"{shortcut_name}.startup_marker"
        try:
            marker.write_text(f"Would create shortcut to: {target_exe}\n", encoding="utf-8")
            return True
        except OSError:
            return False

    try:
        # Prefer winshell / pywin32 if available; otherwise use PowerShell
        try:
            import winshell
            from win32com.client import Dispatch
            shell = Dispatch("WScript.Shell")
            shortcut = shell.CreateShortCut(str(link_path))
            shortcut.Targetpath = str(target_exe)
            if working_dir:
                shortcut.WorkingDirectory = str(working_dir)
            shortcut.IconLocation = str(target_exe)
            shortcut.save()
            return True
        except ImportError:
            # Fallback: PowerShell
            ps = (
                f'$ws = New-Object -ComObject WScript.Shell; '
                f'$s = $ws.CreateShortcut("{link_path}"); '
                f'$s.TargetPath = "{target_exe}"; '
            )
            if working_dir:
                ps += f'$s.WorkingDirectory = "{working_dir}"; '
            ps += f'$s.Save()'
            import subprocess
            subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps],
                check=True,
                capture_output=True
            )
            return True
    except Exception:
        return False


def _remove_shortcut(shortcut_name: str) -> bool:
    startup = _get_startup_folder()
    link_path = startup / f"{shortcut_name}.lnk"
    marker = startup / f"{shortcut_name}.startup_marker"
    removed = False
    for p in (link_path, marker):
        if p.exists():
            try:
                p.unlink()
                removed = True
            except OSError:
                pass
    return removed


def is_startup_enabled(shortcut_name: str) -> bool:
    startup = _get_startup_folder()
    return (startup / f"{shortcut_name}.lnk").exists() or \
           (startup / f"{shortcut_name}.startup_marker").exists()


def enable_rogueshield_startup(exe_path: Path = None) -> bool:
    """Enable RogueShield.exe to start with Windows."""
    if exe_path is None:
        # Assume installed location or current script
        if getattr(sys, "frozen", False):
            exe_path = Path(sys.executable)
        else:
            exe_path = Path(__file__).resolve().parent / "rogueshield.py"
    return _create_shortcut(exe_path, "RogueShield", exe_path.parent)


def disable_rogueshield_startup() -> bool:
    return _remove_shortcut("RogueShield")


def enable_rshost_startup(exe_path: Path = None) -> bool:
    if exe_path is None:
        if getattr(sys, "frozen", False):
            # When running as RSHost, sys.executable is RSHost.exe
            exe_path = Path(sys.executable)
        else:
            exe_path = Path(__file__).resolve().parent / "rshost.py"
    return _create_shortcut(exe_path, "RSHost", exe_path.parent)


def disable_rshost_startup() -> bool:
    return _remove_shortcut("RSHost")
