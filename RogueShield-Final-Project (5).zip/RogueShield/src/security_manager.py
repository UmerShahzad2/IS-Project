"""
RogueShield - Security Manager
Handles password-protected actions (exit, startup changes).
Does NOT prevent Task Manager or OS-level termination.
"""

import tkinter as tk
from tkinter import simpledialog, messagebox
from config_manager import ConfigManager


class SecurityManager:
    def __init__(self, config: ConfigManager, parent=None):
        self.config = config
        self.parent = parent

    def prompt_password(self, title="Authentication Required",
                        prompt="Enter owner password:") -> bool:
        """
        Show a simple password dialog.
        Returns True if password is correct (or no password set).
        """
        if not self.config.has_password():
            return True

        # Use a modal dialog
        root = self.parent
        if root is None:
            root = tk._default_root

        password = simpledialog.askstring(
            title,
            prompt,
            show="*",
            parent=root
        )
        if password is None:
            return False  # User cancelled
        if self.config.check_password(password):
            return True
        messagebox.showerror(
            "Access Denied",
            "Incorrect password.",
            parent=root
        )
        return False

    def require_password_for_exit(self) -> bool:
        return self.prompt_password(
            title="Exit RogueShield",
            prompt="Enter owner password to exit:"
        )

    def require_password_for_startup(self) -> bool:
        return self.prompt_password(
            title="Startup Settings",
            prompt="Enter owner password to change startup options:"
        )

    def change_password(self, parent=None):
        """Interactive password change flow."""
        root = parent or self.parent or tk._default_root

        if self.config.has_password():
            old = simpledialog.askstring(
                "Change Password",
                "Enter current password:",
                show="*",
                parent=root
            )
            if old is None:
                return False
            if not self.config.check_password(old):
                messagebox.showerror("Error", "Current password is incorrect.", parent=root)
                return False

        new1 = simpledialog.askstring(
            "Change Password",
            "Enter new password (leave empty to remove protection):",
            show="*",
            parent=root
        )
        if new1 is None:
            return False

        if new1 == "":
            self.config.set_password("")
            messagebox.showinfo("Password", "Password protection removed.", parent=root)
            return True

        new2 = simpledialog.askstring(
            "Change Password",
            "Confirm new password:",
            show="*",
            parent=root
        )
        if new2 is None or new1 != new2:
            messagebox.showerror("Error", "Passwords do not match.", parent=root)
            return False

        self.config.set_password(new1)
        messagebox.showinfo("Password", "Password changed successfully.", parent=root)
        return True
