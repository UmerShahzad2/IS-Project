#!/usr/bin/env python3
"""
RSHost – Independent Popup & Notification Engine

THIS is the process that owns continuous scareware-style pop-ups.
- Runs independently of RogueShield.exe
- Survives when the main GUI is closed or killed via Task Manager
- Can be set to start with Windows (visible Startup entry)
- Stopping / exiting requires owner password (default: ItsMe2006!)
- Ordinary visible process – not a service, not hidden
"""

import sys
import os
import random
import atexit
from pathlib import Path

SRC_DIR = Path(__file__).resolve().parent
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

import tkinter as tk
from tkinter import messagebox

from popup_manager import PopupManager
from notification_manager import NotificationManager
from config_manager import ConfigManager
from security_manager import SecurityManager
from startup_manager import enable_rshost_startup, is_startup_enabled


BG = "#0D1117"
PANEL = "#161B22"
ACCENT = "#F85149"
TEXT = "#E6EDF3"
SECONDARY = "#8B949E"

# Simple single-instance lock file (best-effort)
LOCK_FILE = Path.home() / ".rogueshield" / "rshost.lock"


def _already_running() -> bool:
    """Return True if another RSHost instance appears to be active."""
    if not LOCK_FILE.exists():
        return False
    try:
        pid = int(LOCK_FILE.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return False
    # Check if process still exists (Windows + Unix)
    if sys.platform == "win32":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            SYNCHRONIZE = 0x00100000
            handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)
            if handle:
                kernel32.CloseHandle(handle)
                return True
            return False
        except Exception:
            return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def _write_lock():
    try:
        LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
        LOCK_FILE.write_text(str(os.getpid()), encoding="utf-8")
    except OSError:
        pass


def _clear_lock():
    try:
        if LOCK_FILE.exists():
            LOCK_FILE.unlink()
    except OSError:
        pass


class RSHostApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("RSHost – RogueShield Background Engine")
        self.geometry("440x380")
        self.resizable(False, False)
        self.configure(bg=BG)

        self.config = ConfigManager()
        self.security = SecurityManager(self.config, parent=self)
        self.popup_mgr = PopupManager(self)
        self.notify = NotificationManager(self)

        # Ensure RSHost is set to start with Windows (visible entry)
        if not is_startup_enabled("RSHost"):
            try:
                enable_rshost_startup()
                self.config.set("startup_rshost", True)
            except Exception:
                pass

        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close_request)

        # Start continuous pop-ups immediately – this is the core engine
        self.after(300, self._start_engine)

        # Optional: start minimized so user mainly sees pop-ups
        # Uncomment next line if you want the control window hidden by default:
        # self.after(100, self.iconify)

    def _build_ui(self):
        tk.Label(
            self, text="RSHost",
            font=("Segoe UI", 18, "bold"),
            fg=ACCENT, bg=BG
        ).pack(pady=(18, 2))

        tk.Label(
            self, text="Independent Pop-up Engine",
            font=("Segoe UI", 10),
            fg=SECONDARY, bg=BG
        ).pack()

        info = tk.Label(
            self,
            text=(
                "This process owns the continuous security pop-ups.\n"
                "Closing or killing the main RogueShield window\n"
                "does NOT stop these pop-ups.\n\n"
                "RSHost stays in Task Manager until you stop it\n"
                "here (password required) or end the process."
            ),
            font=("Segoe UI", 9),
            fg=TEXT, bg=BG, justify="center"
        )
        info.pack(pady=12)

        self.status = tk.Label(
            self, text="Status: STARTING…",
            font=("Segoe UI", 10, "bold"),
            fg=SECONDARY, bg=BG
        )
        self.status.pack(pady=4)

        btn_frame = tk.Frame(self, bg=BG)
        btn_frame.pack(pady=14)

        tk.Button(
            btn_frame, text="Start Engine",
            font=("Segoe UI", 10, "bold"),
            bg=ACCENT, fg="white", relief="flat",
            padx=12, pady=6, command=self._start_engine
        ).pack(side="left", padx=5)

        tk.Button(
            btn_frame, text="Stop (Password)",
            font=("Segoe UI", 10, "bold"),
            bg="#333333", fg="white", relief="flat",
            padx=12, pady=6, command=self._stop_protected
        ).pack(side="left", padx=5)

        tk.Button(
            self, text="Exit RSHost (Password Required)",
            font=("Segoe UI", 9),
            bg=PANEL, fg=TEXT, relief="flat",
            padx=12, pady=5, command=self._on_close_request
        ).pack(pady=6)

        tk.Label(
            self,
            text="Default password: ItsMe2006!   •   Educational use only",
            font=("Segoe UI", 8),
            fg=SECONDARY, bg=BG
        ).pack(side="bottom", pady=10)

    def _start_engine(self):
        """Begin continuous independent pop-ups."""
        if not self.popup_mgr.is_active():
            self.popup_mgr.start()
        self.status.configure(text="Status: POP-UPS ACTIVE (independent)", fg=ACCENT)
        self._toast_loop()

    def _stop_protected(self):
        if not self.security.prompt_password(
            title="Stop RSHost Engine",
            prompt="Enter owner password to stop pop-ups:"
        ):
            return
        self._stop_engine()
        messagebox.showinfo("RSHost", "Pop-up engine stopped.")

    def _stop_engine(self):
        self.popup_mgr.stop()
        self.status.configure(text="Status: STOPPED", fg="#3FB950")
        if hasattr(self, "_toast_id"):
            try:
                self.after_cancel(self._toast_id)
            except Exception:
                pass

    def _toast_loop(self):
        if not self.popup_mgr.is_active():
            return
        self.notify.show_random()
        delay = int(random.uniform(4.0, 9.0) * 1000)
        self._toast_id = self.after(delay, self._toast_loop)

    def _on_close_request(self):
        if not self.security.prompt_password(
            title="Exit RSHost",
            prompt="Enter owner password to exit RSHost:"
        ):
            return
        self._stop_engine()
        self.popup_mgr.cleanup()
        self.destroy()


def main():
    # Single-instance: if already running, just exit silently
    if _already_running():
        # Another RSHost is already generating pop-ups
        return

    _write_lock()
    atexit.register(_clear_lock)

    app = RSHostApp()
    app.mainloop()
    _clear_lock()


if __name__ == "__main__":
    main()
