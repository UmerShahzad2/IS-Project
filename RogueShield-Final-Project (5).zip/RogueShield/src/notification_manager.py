"""
RogueShield - Notification Manager
Used by both main app and RSHost for tray-style / toast-style simulated alerts.
"""

import random
import tkinter as tk
from typing import Optional, Callable


NOTIFICATION_TITLES = [
    "RogueShield Alert",
    "Security Notification",
    "Protection Status",
    "Scan Complete",
    "System Check",
]

NOTIFICATION_BODIES = [
    "Background protection is active (simulation).",
    "No real threats were found – this is a demo notification.",
    "Educational reminder: always verify antivirus alerts.",
    "RogueShield demo: scheduled check finished.",
    "Your system remains under simulated monitoring.",
]


class ToastNotification(tk.Toplevel):
    """Simple non-modal toast in the bottom-right corner."""

    def __init__(self, master, title: str, body: str, duration_ms: int = 4500):
        super().__init__(master)
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(bg="#1E1E2E")

        frame = tk.Frame(self, bg="#1E1E2E", padx=14, pady=10,
                         highlightbackground="#FF4444", highlightthickness=2)
        frame.pack(fill="both", expand=True)

        tk.Label(frame, text=title, font=("Segoe UI", 10, "bold"),
                 fg="#FF6666", bg="#1E1E2E").pack(anchor="w")
        tk.Label(frame, text=body, font=("Segoe UI", 9),
                 fg="#CCCCCC", bg="#1E1E2E", wraplength=280,
                 justify="left").pack(anchor="w", pady=(4, 0))

        self.update_idletasks()
        w = self.winfo_reqwidth()
        h = self.winfo_reqheight()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x = sw - w - 30
        y = sh - h - 70
        self.geometry(f"+{x}+{y}")

        self.after(duration_ms, self._fade_out)

    def _fade_out(self):
        try:
            self.destroy()
        except tk.TclError:
            pass


class NotificationManager:
    def __init__(self, root: tk.Tk):
        self.root = root
        self._enabled = True

    def enable(self):
        self._enabled = True

    def disable(self):
        self._enabled = False

    def show_random(self):
        if not self._enabled:
            return
        title = random.choice(NOTIFICATION_TITLES)
        body = random.choice(NOTIFICATION_BODIES)
        try:
            ToastNotification(self.root, title, body)
        except tk.TclError:
            pass

    def show(self, title: str, body: str):
        if not self._enabled:
            return
        try:
            ToastNotification(self.root, title, body)
        except tk.TclError:
            pass
