"""
RogueShield - Fast Random Popup Manager
HIGHEST PRIORITY FEATURE

Generates rapid, unpredictable simulated antivirus warning pop-ups.
- Random delay 0.2 – 1.5 seconds
- Random screen positions
- Varied titles, messages, colors, severity
- No artificial count limit while active
- Instant stop via cancel of all scheduled events
- Clean resource cleanup
"""

import random
import tkinter as tk
from tkinter import ttk
from typing import Optional, Callable
import threading


# Warning content pools – purely fictional / educational
TITLES = [
    "CRITICAL SECURITY ALERT",
    "Threat Detected!",
    "System Integrity Warning",
    "Malware Activity Detected",
    "Firewall Breach Attempt",
    "Suspicious Process Found",
    "Immediate Action Required",
    "High Severity Alert",
    "RogueShield Protection",
    "Security Risk Identified",
]

MESSAGES = [
    "A potential threat has been simulated for demonstration purposes.\nNo real infection exists.",
    "Educational simulation: suspicious behaviour pattern observed.\nThis is not a real threat.",
    "Demo alert – your system is safe.\nRogueShield is showing how scareware looks.",
    "Simulated detection of unknown executable.\nThis is a training demonstration only.",
    "Network activity flagged (simulation).\nNo actual network changes were made.",
    "Memory scan simulation completed with findings.\nAll data is fictional.",
    "Registry anomaly simulated for education.\nYour registry was not modified.",
    "Multiple threat indicators (demo mode).\nStop the simulation at any time.",
    "This pop-up is part of the RogueShield educational experience.\nYour PC is not infected.",
    "Scareware-style warning for training.\nUse the STOP button to end the demo.",
]

SEVERITIES = [
    ("CRITICAL", "#8B0000", "#FF4444"),   # dark red bg, bright red accent
    ("HIGH", "#4A0000", "#FF6666"),
    ("MEDIUM", "#3D2B00", "#FFAA00"),
    ("WARNING", "#1A1A2E", "#00D4FF"),
]


class WarningPopup(tk.Toplevel):
    """A single simulated warning window."""

    def __init__(self, master, on_close: Optional[Callable] = None):
        super().__init__(master)
        self.on_close = on_close
        self._build()
        self._place_randomly()
        self.attributes("-topmost", True)
        self.protocol("WM_DELETE_WINDOW", self._close)

    def _build(self):
        title = random.choice(TITLES)
        message = random.choice(MESSAGES)
        severity, bg, accent = random.choice(SEVERITIES)

        self.title(f"RogueShield – {severity}")
        self.configure(bg=bg)
        self.resizable(False, False)
        self.geometry("420x220")

        # Header
        header = tk.Frame(self, bg=accent, height=8)
        header.pack(fill="x")

        body = tk.Frame(self, bg=bg, padx=16, pady=12)
        body.pack(fill="both", expand=True)

        tk.Label(
            body,
            text="⚠  " + title,
            font=("Segoe UI", 12, "bold"),
            fg="white",
            bg=bg,
            wraplength=380,
            justify="left"
        ).pack(anchor="w", pady=(0, 8))

        tk.Label(
            body,
            text=message,
            font=("Segoe UI", 9),
            fg="#DDDDDD",
            bg=bg,
            wraplength=380,
            justify="left"
        ).pack(anchor="w", pady=(0, 12))

        btn_frame = tk.Frame(body, bg=bg)
        btn_frame.pack(fill="x")

        tk.Button(
            btn_frame,
            text="Acknowledge (Demo)",
            command=self._close,
            bg=accent,
            fg="white",
            activebackground="#FFFFFF",
            activeforeground=bg,
            relief="flat",
            padx=12,
            pady=4,
            font=("Segoe UI", 9, "bold")
        ).pack(side="left")

        tk.Label(
            btn_frame,
            text="Educational simulation only",
            font=("Segoe UI", 8),
            fg="#888888",
            bg=bg
        ).pack(side="right")

    def _place_randomly(self):
        self.update_idletasks()
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        w, h = 420, 220
        # Keep fully on screen with some margin
        x = random.randint(20, max(20, sw - w - 40))
        y = random.randint(20, max(20, sh - h - 80))
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _close(self):
        if self.on_close:
            self.on_close(self)
        try:
            self.destroy()
        except tk.TclError:
            pass


class PopupManager:
    """
    Controls continuous random popup generation.
    Designed for low overhead and immediate stop.
    """

    def __init__(self, root: tk.Tk):
        self.root = root
        self.active = False
        self._after_id: Optional[str] = None
        self._open_popups: list = []
        self._lock = threading.Lock()
        self._max_visible = 12  # soft visual limit only; generation continues

    def start(self):
        """Begin continuous random popup generation."""
        if self.active:
            return
        self.active = True
        self._schedule_next()

    def stop(self):
        """Immediately cancel all scheduled popups and close existing ones."""
        self.active = False
        if self._after_id is not None:
            try:
                self.root.after_cancel(self._after_id)
            except (tk.TclError, ValueError):
                pass
            self._after_id = None

        # Close all open popups
        with self._lock:
            for p in list(self._open_popups):
                try:
                    p.destroy()
                except tk.TclError:
                    pass
            self._open_popups.clear()

    def is_active(self) -> bool:
        return self.active

    def _schedule_next(self):
        if not self.active:
            return
        delay_ms = int(random.uniform(0.2, 1.5) * 1000)
        self._after_id = self.root.after(delay_ms, self._fire)

    def _fire(self):
        if not self.active:
            return

        # Sometimes burst several popups quickly
        burst = 1
        if random.random() < 0.25:
            burst = random.randint(2, 4)

        for _ in range(burst):
            if not self.active:
                break
            self._create_popup()

        self._schedule_next()

    def _create_popup(self):
        # Soft limit on simultaneous visible windows to avoid overwhelming the desktop
        with self._lock:
            if len(self._open_popups) >= self._max_visible:
                # Still schedule next; just skip creating more right now
                return

        def on_close(popup):
            with self._lock:
                if popup in self._open_popups:
                    self._open_popups.remove(popup)

        try:
            popup = WarningPopup(self.root, on_close=on_close)
            with self._lock:
                self._open_popups.append(popup)
        except tk.TclError:
            # Root may have been destroyed
            self.active = False

    def cleanup(self):
        """Full cleanup – call on application exit."""
        self.stop()
