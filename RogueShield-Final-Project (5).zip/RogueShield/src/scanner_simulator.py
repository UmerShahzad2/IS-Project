"""
RogueShield - Scanner Simulator
All scanning is pure simulation. No real files are scanned or modified.
"""

import random
import time
import threading
from datetime import datetime
from typing import Callable, Optional, List


# Fictional threat names for educational demonstration
FAKE_THREATS = [
    "Trojan.Generic.SimDemo",
    "PUA.Adware.Training",
    "Heuristic.Suspicious.Behaviour",
    "Worm.Simulated.Net",
    "Ransom.Demo.Note",
    "Backdoor.Educational",
    "Spyware.Fake.Keylogger",
    "Malware.Test.Signature",
    "Exploit.Kit.Demo",
    "Rootkit.Simulated",
]

FAKE_PATHS = [
    r"C:\Users\Public\Downloads\setup_helper.exe",
    r"C:\Temp\update_check.tmp",
    r"C:\ProgramData\cache\svc_host.dll",
    r"C:\Users\Demo\AppData\Local\Temp\~tmp123.dat",
    r"C:\Windows\Temp\perf_boost.sys",
    r"C:\Users\Public\Documents\invoice_scan.pdf.exe",
]


class ScanResult:
    def __init__(self, threats_found: int, files_scanned: int, duration: float,
                 threat_list: List[dict]):
        self.threats_found = threats_found
        self.files_scanned = files_scanned
        self.duration = duration
        self.threat_list = threat_list
        self.timestamp = datetime.now().isoformat(timespec="seconds")


class ScannerSimulator:
    def __init__(self):
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._cancel = False

    def is_running(self) -> bool:
        return self._running

    def cancel(self):
        self._cancel = True

    def quick_scan(self, progress_cb: Callable[[int, str], None],
                   finished_cb: Callable[[ScanResult], None]):
        """Simulate a quick scan (few seconds)."""
        self._start_scan(
            total_steps=40,
            base_files=1200,
            threat_chance=0.15,
            progress_cb=progress_cb,
            finished_cb=finished_cb,
            label="Quick Scan"
        )

    def full_scan(self, progress_cb: Callable[[int, str], None],
                  finished_cb: Callable[[ScanResult], None]):
        """Simulate a full system scan (longer)."""
        self._start_scan(
            total_steps=120,
            base_files=18500,
            threat_chance=0.25,
            progress_cb=progress_cb,
            finished_cb=finished_cb,
            label="Full System Scan"
        )

    def _start_scan(self, total_steps, base_files, threat_chance,
                    progress_cb, finished_cb, label):
        if self._running:
            return
        self._running = True
        self._cancel = False

        def worker():
            start = time.time()
            threats = []
            files = 0
            for i in range(total_steps + 1):
                if self._cancel:
                    break
                pct = int((i / total_steps) * 100)
                files = int(base_files * (i / total_steps))
                status = f"{label}: scanning simulated locations... ({files} items)"
                try:
                    progress_cb(pct, status)
                except Exception:
                    break
                # Occasional "threat" discovery
                if random.random() < threat_chance / total_steps * 8 and len(threats) < 8:
                    t = {
                        "name": random.choice(FAKE_THREATS),
                        "path": random.choice(FAKE_PATHS),
                        "severity": random.choice(["High", "Medium", "Low"]),
                        "action": "Quarantined (simulation)"
                    }
                    threats.append(t)
                time.sleep(random.uniform(0.04, 0.12))

            duration = time.time() - start
            result = ScanResult(
                threats_found=len(threats),
                files_scanned=files,
                duration=round(duration, 1),
                threat_list=threats
            )
            self._running = False
            try:
                finished_cb(result)
            except Exception:
                pass

        self._thread = threading.Thread(target=worker, daemon=True)
        self._thread.start()
