#!/usr/bin/env python3
"""
RogueShield – Main Application
Educational rogue-antivirus behaviour simulator.
All operations are simulated. No real system changes are performed.
"""

import sys
import os
import random
import subprocess
from pathlib import Path
from datetime import datetime

# Ensure src is on path when run from source
SRC_DIR = Path(__file__).resolve().parent
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext

from config_manager import ConfigManager
from security_manager import SecurityManager
from startup_manager import (
    enable_rogueshield_startup, disable_rogueshield_startup,
    enable_rshost_startup, disable_rshost_startup,
    is_startup_enabled
)
from popup_manager import PopupManager
from scanner_simulator import ScannerSimulator
from notification_manager import NotificationManager


# ─────────────────────────────────────────────────────────────
# Colour palette (dark security theme)
# ─────────────────────────────────────────────────────────────
BG_DARK = "#0D1117"
BG_PANEL = "#161B22"
BG_CARD = "#21262D"
ACCENT_RED = "#F85149"
ACCENT_GREEN = "#3FB950"
ACCENT_BLUE = "#58A6FF"
ACCENT_ORANGE = "#D29922"
TEXT_PRIMARY = "#E6EDF3"
TEXT_SECONDARY = "#8B949E"
BORDER = "#30363D"


class RogueShieldApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("RogueShield – Educational Security Simulator")
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.configure(bg=BG_DARK)

        # Managers
        self.config = ConfigManager()
        self.security = SecurityManager(self.config, parent=self)
        self.popup_mgr = PopupManager(self)
        self.scanner = ScannerSimulator()
        self.notify = NotificationManager(self)

        self.current_page = "dashboard"
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close_request)

        # Demo files on first run
        if self.config.get("first_run", True):
            self.after(800, self._create_demo_files)
            self.config.set("first_run", False)

        # Launch RSHost as a completely separate process.
        # RSHost owns ALL continuous pop-ups. Killing/closing this main
        # window does NOT stop pop-ups – only stopping RSHost does.
        self.after(300, self._launch_rshost_independent)

    # ── UI Construction ──────────────────────────────────────
    def _build_ui(self):
        # Top bar
        top = tk.Frame(self, bg=BG_PANEL, height=56)
        top.pack(fill="x")
        top.pack_propagate(False)

        tk.Label(
            top, text="🛡  RogueShield",
            font=("Segoe UI", 16, "bold"),
            fg=ACCENT_RED, bg=BG_PANEL
        ).pack(side="left", padx=20, pady=12)

        tk.Label(
            top, text="EDUCATIONAL SIMULATOR  •  NO REAL THREATS",
            font=("Segoe UI", 9),
            fg=TEXT_SECONDARY, bg=BG_PANEL
        ).pack(side="left", padx=10)

        self.status_label = tk.Label(
            top, text="Pop-ups: via RSHost (independent)",
            font=("Segoe UI", 9),
            fg=ACCENT_RED, bg=BG_PANEL
        )
        self.status_label.pack(side="right", padx=16)

        # Main body: sidebar + content
        body = tk.Frame(self, bg=BG_DARK)
        body.pack(fill="both", expand=True)

        # Sidebar
        side = tk.Frame(body, bg=BG_PANEL, width=220)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)

        nav_items = [
            ("Dashboard", "dashboard"),
            ("Quick Scan", "quick_scan"),
            ("Full System Scan", "full_scan"),
            ("Network Optimization", "network"),
            ("Firewall Protection", "firewall"),
            ("Performance Boost", "performance"),
            ("Quarantine", "quarantine"),
            ("Security History", "history"),
            ("Settings", "settings"),
        ]

        self.nav_buttons = {}
        for label, key in nav_items:
            btn = tk.Button(
                side, text=label, anchor="w",
                font=("Segoe UI", 10),
                bg=BG_PANEL, fg=TEXT_PRIMARY,
                activebackground=BG_CARD, activeforeground=TEXT_PRIMARY,
                relief="flat", padx=20, pady=12,
                command=lambda k=key: self._show_page(k)
            )
            btn.pack(fill="x")
            self.nav_buttons[key] = btn

        # Content area
        self.content = tk.Frame(body, bg=BG_DARK)
        self.content.pack(side="left", fill="both", expand=True, padx=16, pady=12)

        self.pages = {}
        self._build_dashboard()
        self._build_scan_page("quick_scan", "Quick Scan")
        self._build_scan_page("full_scan", "Full System Scan")
        self._build_placeholder("network", "Network Optimization",
                                "Simulated network optimisation.\nNo real network settings are changed.")
        self._build_placeholder("firewall", "Firewall Protection",
                                "Simulated firewall status.\nWindows Firewall is not modified.")
        self._build_placeholder("performance", "Performance Boost",
                                "Simulated performance tips.\nNo system services are altered.")
        self._build_quarantine()
        self._build_history()
        self._build_settings()

        self._show_page("dashboard")

    def _clear_content(self):
        for w in self.content.winfo_children():
            w.pack_forget()

    def _show_page(self, key: str):
        self.current_page = key
        self._clear_content()
        for k, btn in self.nav_buttons.items():
            btn.configure(bg=BG_CARD if k == key else BG_PANEL)
        page = self.pages.get(key)
        if page:
            page.pack(fill="both", expand=True)

    # ── Pages ────────────────────────────────────────────────
    def _build_dashboard(self):
        f = tk.Frame(self.content, bg=BG_DARK)
        self.pages["dashboard"] = f

        # Status cards
        cards = tk.Frame(f, bg=BG_DARK)
        cards.pack(fill="x", pady=(0, 16))

        self._card(cards, "Protection", "ACTIVE (Sim)", ACCENT_GREEN).pack(side="left", padx=(0, 12))
        self._card(cards, "Threats Blocked", "0 (Demo)", ACCENT_BLUE).pack(side="left", padx=(0, 12))
        self._card(cards, "Last Scan", "Never", ACCENT_ORANGE).pack(side="left", padx=(0, 12))
        self._card(cards, "Pop-ups", "RSHost (independent)", ACCENT_RED).pack(side="left")

        # Main actions
        act = tk.LabelFrame(f, text="  Simulation Controls  ",
                            font=("Segoe UI", 11, "bold"),
                            fg=TEXT_PRIMARY, bg=BG_DARK,
                            labelanchor="n")
        act.pack(fill="x", pady=8)

        btn_row = tk.Frame(act, bg=BG_DARK)
        btn_row.pack(pady=16)

        tk.Button(
            btn_row, text="▶  Ensure RSHost Running",
            font=("Segoe UI", 11, "bold"),
            bg=ACCENT_RED, fg="white", relief="flat",
            padx=20, pady=10,
            command=self._launch_rshost_independent
        ).pack(side="left", padx=8)

        tk.Button(
            btn_row, text="Quick Scan (Sim)",
            font=("Segoe UI", 10),
            bg=BG_CARD, fg=TEXT_PRIMARY, relief="flat",
            padx=16, pady=10,
            command=lambda: self._show_page("quick_scan")
        ).pack(side="left", padx=8)

        tk.Button(
            btn_row, text="Full Scan (Sim)",
            font=("Segoe UI", 10),
            bg=BG_CARD, fg=TEXT_PRIMARY, relief="flat",
            padx=16, pady=10,
            command=lambda: self._show_page("full_scan")
        ).pack(side="left", padx=8)

        # Info box
        info = tk.LabelFrame(f, text="  Important  ",
                             font=("Segoe UI", 10, "bold"),
                             fg=ACCENT_ORANGE, bg=BG_DARK)
        info.pack(fill="both", expand=True, pady=12)

        msg = (
            "RogueShield is an EDUCATIONAL tool that demonstrates how rogue antivirus "
            "(scareware) applications behave.\n\n"
            "• All scans, threats, quarantine items and notifications are completely simulated.\n"
            "• Continuous pop-ups are owned by the independent RSHost process.\n"
            "• Closing or killing THIS main window does NOT stop the pop-ups.\n"
            "• After reboot, RSHost is set to start automatically (visible Startup entry).\n"
            "• To stop pop-ups: open RSHost → Stop (password) or end RSHost in Task Manager.\n"
            "• Default password: ItsMe2006!  (changeable in Settings)"
        )
        tk.Label(info, text=msg, justify="left", font=("Segoe UI", 9),
                 fg=TEXT_SECONDARY, bg=BG_DARK, wraplength=800).pack(padx=16, pady=12, anchor="w")

    def _card(self, parent, title, value, color):
        c = tk.Frame(parent, bg=BG_CARD, padx=16, pady=12,
                     highlightbackground=BORDER, highlightthickness=1)
        tk.Label(c, text=title, font=("Segoe UI", 9),
                 fg=TEXT_SECONDARY, bg=BG_CARD).pack(anchor="w")
        tk.Label(c, text=value, font=("Segoe UI", 16, "bold"),
                 fg=color, bg=BG_CARD).pack(anchor="w", pady=(4, 0))
        return c

    def _build_scan_page(self, key, title):
        f = tk.Frame(self.content, bg=BG_DARK)
        self.pages[key] = f

        tk.Label(f, text=title, font=("Segoe UI", 14, "bold"),
                 fg=TEXT_PRIMARY, bg=BG_DARK).pack(anchor="w")

        self.scan_status = {}
        status = tk.Label(f, text="Ready to start simulated scan.",
                          font=("Segoe UI", 10), fg=TEXT_SECONDARY, bg=BG_DARK)
        status.pack(anchor="w", pady=(8, 4))
        self.scan_status[key] = status

        prog = ttk.Progressbar(f, length=500, mode="determinate")
        prog.pack(anchor="w", pady=8)
        self.scan_progress = getattr(self, "scan_progress", {})
        self.scan_progress[key] = prog

        result_box = scrolledtext.ScrolledText(
            f, height=14, bg=BG_CARD, fg=TEXT_PRIMARY,
            insertbackground=TEXT_PRIMARY, font=("Consolas", 9),
            relief="flat"
        )
        result_box.pack(fill="both", expand=True, pady=8)
        self.scan_results = getattr(self, "scan_results", {})
        self.scan_results[key] = result_box

        btn_row = tk.Frame(f, bg=BG_DARK)
        btn_row.pack(anchor="w", pady=8)

        def start():
            if self.scanner.is_running():
                messagebox.showinfo("Scan", "A scan is already in progress.")
                return
            result_box.delete("1.0", "end")
            result_box.insert("end", f"Starting {title} (simulation)...\n")
            prog["value"] = 0

            def progress(pct, msg):
                self.after(0, lambda: prog.configure(value=pct))
                self.after(0, lambda: status.configure(text=msg))

            def finished(result):
                def ui():
                    status.configure(text=f"Completed – {result.threats_found} simulated threats, "
                                          f"{result.files_scanned} items, {result.duration}s")
                    result_box.insert("end", f"\n=== Scan Finished ===\n")
                    result_box.insert("end", f"Threats (simulated): {result.threats_found}\n")
                    result_box.insert("end", f"Items examined: {result.files_scanned}\n")
                    result_box.insert("end", f"Duration: {result.duration}s\n\n")
                    for t in result.threat_list:
                        result_box.insert("end",
                            f"  [{t['severity']}] {t['name']}\n"
                            f"      Path: {t['path']}\n"
                            f"      Action: {t['action']}\n\n")
                        self.config.add_quarantine(t)
                    self.config.add_scan_history({
                        "type": title,
                        "threats": result.threats_found,
                        "files": result.files_scanned,
                        "duration": result.duration,
                        "time": result.timestamp
                    })
                    if result.threats_found:
                        self.notify.show("Scan Complete",
                                         f"{result.threats_found} simulated threats quarantined.")
                self.after(0, ui)

            if key == "quick_scan":
                self.scanner.quick_scan(progress, finished)
            else:
                self.scanner.full_scan(progress, finished)

        tk.Button(btn_row, text="Start Simulation", bg=ACCENT_BLUE, fg="white",
                  relief="flat", padx=14, pady=6, command=start).pack(side="left", padx=(0, 8))
        tk.Button(btn_row, text="Cancel", bg=BG_CARD, fg=TEXT_PRIMARY,
                  relief="flat", padx=14, pady=6,
                  command=self.scanner.cancel).pack(side="left")

    def _build_placeholder(self, key, title, body):
        f = tk.Frame(self.content, bg=BG_DARK)
        self.pages[key] = f
        tk.Label(f, text=title, font=("Segoe UI", 14, "bold"),
                 fg=TEXT_PRIMARY, bg=BG_DARK).pack(anchor="w")
        tk.Label(f, text=body, font=("Segoe UI", 10),
                 fg=TEXT_SECONDARY, bg=BG_DARK, justify="left").pack(anchor="w", pady=16)

    def _build_quarantine(self):
        f = tk.Frame(self.content, bg=BG_DARK)
        self.pages["quarantine"] = f
        tk.Label(f, text="Quarantine (Simulated)", font=("Segoe UI", 14, "bold"),
                 fg=TEXT_PRIMARY, bg=BG_DARK).pack(anchor="w")

        self.q_list = scrolledtext.ScrolledText(
            f, height=18, bg=BG_CARD, fg=TEXT_PRIMARY,
            font=("Consolas", 9), relief="flat"
        )
        self.q_list.pack(fill="both", expand=True, pady=8)

        def refresh():
            self.q_list.delete("1.0", "end")
            items = self.config.get("quarantine_list", [])
            if not items:
                self.q_list.insert("end", "No items in simulated quarantine.\n")
            else:
                for i, t in enumerate(items, 1):
                    self.q_list.insert("end",
                        f"{i}. [{t.get('severity','?')}] {t.get('name','?')}\n"
                        f"   {t.get('path','')}\n"
                        f"   {t.get('action','')}\n\n")

        def clear():
            self.config.clear_quarantine()
            refresh()

        btn_row = tk.Frame(f, bg=BG_DARK)
        btn_row.pack(anchor="w")
        tk.Button(btn_row, text="Refresh", bg=BG_CARD, fg=TEXT_PRIMARY,
                  relief="flat", padx=12, pady=4, command=refresh).pack(side="left", padx=(0, 8))
        tk.Button(btn_row, text="Clear All (Sim)", bg=ACCENT_ORANGE, fg="white",
                  relief="flat", padx=12, pady=4, command=clear).pack(side="left")
        refresh()

    def _build_history(self):
        f = tk.Frame(self.content, bg=BG_DARK)
        self.pages["history"] = f
        tk.Label(f, text="Security History (Simulated)", font=("Segoe UI", 14, "bold"),
                 fg=TEXT_PRIMARY, bg=BG_DARK).pack(anchor="w")

        self.hist_list = scrolledtext.ScrolledText(
            f, height=20, bg=BG_CARD, fg=TEXT_PRIMARY,
            font=("Consolas", 9), relief="flat"
        )
        self.hist_list.pack(fill="both", expand=True, pady=8)

        def refresh():
            self.hist_list.delete("1.0", "end")
            hist = self.config.get("scan_history", [])
            if not hist:
                self.hist_list.insert("end", "No scan history yet.\n")
            else:
                for h in hist:
                    self.hist_list.insert("end",
                        f"[{h.get('time','')}] {h.get('type','')} – "
                        f"{h.get('threats',0)} threats, {h.get('files',0)} items, "
                        f"{h.get('duration',0)}s\n")

        tk.Button(f, text="Refresh", bg=BG_CARD, fg=TEXT_PRIMARY,
                  relief="flat", padx=12, pady=4, command=refresh).pack(anchor="w")
        refresh()

    def _build_settings(self):
        f = tk.Frame(self.content, bg=BG_DARK)
        self.pages["settings"] = f
        tk.Label(f, text="Settings", font=("Segoe UI", 14, "bold"),
                 fg=TEXT_PRIMARY, bg=BG_DARK).pack(anchor="w")

        # Password section
        pw = tk.LabelFrame(f, text="  Owner Password  ", fg=TEXT_PRIMARY, bg=BG_DARK)
        pw.pack(fill="x", pady=12)
        tk.Label(pw, text="Protects application exit and startup configuration changes.",
                 fg=TEXT_SECONDARY, bg=BG_DARK, font=("Segoe UI", 9)).pack(anchor="w", padx=12, pady=4)
        tk.Button(pw, text="Change / Set Password", bg=BG_CARD, fg=TEXT_PRIMARY,
                  relief="flat", padx=12, pady=4,
                  command=lambda: self.security.change_password(self)).pack(anchor="w", padx=12, pady=8)

        # Startup section
        su = tk.LabelFrame(f, text="  Startup Integration (Visible)  ", fg=TEXT_PRIMARY, bg=BG_DARK)
        su.pack(fill="x", pady=12)
        tk.Label(su,
                 text="Creates normal shortcuts in the Windows Startup folder.\n"
                      "Visible in Settings → Apps → Startup. No hidden tasks.",
                 fg=TEXT_SECONDARY, bg=BG_DARK, font=("Segoe UI", 9),
                 justify="left").pack(anchor="w", padx=12, pady=4)

        self.var_rs = tk.BooleanVar(value=is_startup_enabled("RogueShield"))
        self.var_host = tk.BooleanVar(value=is_startup_enabled("RSHost"))

        def toggle_rs():
            if not self.security.require_password_for_startup():
                self.var_rs.set(not self.var_rs.get())
                return
            if self.var_rs.get():
                enable_rogueshield_startup()
            else:
                disable_rogueshield_startup()
            self.config.set("startup_rogueshield", self.var_rs.get())

        def toggle_host():
            if not self.security.require_password_for_startup():
                self.var_host.set(not self.var_host.get())
                return
            if self.var_host.get():
                enable_rshost_startup()
            else:
                disable_rshost_startup()
            self.config.set("startup_rshost", self.var_host.get())

        tk.Checkbutton(su, text="Start RogueShield with Windows",
                       variable=self.var_rs, command=toggle_rs,
                       fg=TEXT_PRIMARY, bg=BG_DARK, selectcolor=BG_CARD,
                       activebackground=BG_DARK, activeforeground=TEXT_PRIMARY
                       ).pack(anchor="w", padx=12, pady=4)
        tk.Checkbutton(su, text="Start RSHost (background notifier) with Windows",
                       variable=self.var_host, command=toggle_host,
                       fg=TEXT_PRIMARY, bg=BG_DARK, selectcolor=BG_CARD,
                       activebackground=BG_DARK, activeforeground=TEXT_PRIMARY
                       ).pack(anchor="w", padx=12, pady=4)

        # About
        about = tk.LabelFrame(f, text="  About  ", fg=TEXT_PRIMARY, bg=BG_DARK)
        about.pack(fill="x", pady=12)
        tk.Label(about,
                 text="RogueShield v1.0 – Educational Scareware Simulator\n"
                      "All features are simulated for security awareness training.\n"
                      "See SECURITY_AND_SCOPE.md and LICENSE.txt for details.",
                 fg=TEXT_SECONDARY, bg=BG_DARK, font=("Segoe UI", 9),
                 justify="left").pack(anchor="w", padx=12, pady=8)

    # ── Demo files ───────────────────────────────────────────
    def _create_demo_files(self):
        desktop = Path.home() / "Desktop"
        if not desktop.exists():
            desktop = Path.home() / "OneDrive" / "Desktop"
        if not desktop.exists():
            desktop = Path.home()
        demo_dir = desktop / "RogueShield-Demo"
        try:
            demo_dir.mkdir(parents=True, exist_ok=True)
            files = {
                "Threat_Report.txt": (
                    "RogueShield Educational Threat Report\n"
                    "=====================================\n"
                    "This file is a harmless demonstration artefact.\n"
                    "No real threats were detected or quarantined.\n"
                    "Generated for security-awareness training only.\n"
                ),
                "Security_Alert.txt": (
                    "RogueShield Security Alert (Simulated)\n"
                    "======================================\n"
                    "Alert Level: DEMO\n"
                    "Message: This is a fictional security alert used to illustrate\n"
                    "how scareware applications present urgent warnings.\n"
                    "Your system has not been modified.\n"
                ),
                "Scan_Result.txt": (
                    "RogueShield Scan Result (Simulation)\n"
                    "====================================\n"
                    "Scan Type: Full System (simulated)\n"
                    "Items examined: fictional\n"
                    "Threats found: 0 real / several simulated\n"
                    "Action taken: none (demo only)\n"
                ),
                "System_Report.txt": (
                    "RogueShield System Report\n"
                    "=========================\n"
                    "Status: Educational mode active\n"
                    "Real system changes: NONE\n"
                    "Purpose: Demonstrate rogue-antivirus behaviour safely.\n"
                ),
            }
            for name, content in files.items():
                (demo_dir / name).write_text(content, encoding="utf-8")
        except OSError:
            pass

    # ── Independent RSHost process ───────────────────────────
    def _launch_rshost_independent(self):
        """
        Start RSHost as a fully separate OS process.
        When the main RogueShield window is closed, RSHost continues
        running and remains visible in Task Manager.
        """
        try:
            if getattr(sys, "frozen", False):
                # Running as packaged .exe – look for RSHost.exe next to us
                base = Path(sys.executable).resolve().parent
                rshost_exe = base / "RSHost.exe"
                if rshost_exe.exists():
                    creationflags = 0
                    if sys.platform == "win32":
                        # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
                        creationflags = 0x00000008 | 0x00000200
                    subprocess.Popen(
                        [str(rshost_exe)],
                        cwd=str(base),
                        creationflags=creationflags,
                        close_fds=True,
                    )
                    return
            # Running from source
            rshost_py = SRC_DIR / "rshost.py"
            if rshost_py.exists():
                creationflags = 0
                if sys.platform == "win32":
                    creationflags = 0x00000008 | 0x00000200
                subprocess.Popen(
                    [sys.executable, str(rshost_py)],
                    cwd=str(SRC_DIR),
                    creationflags=creationflags,
                    close_fds=True,
                )
        except Exception:
            # Non-fatal – main app continues even if RSHost fails to start
            pass

    # ── Exit ─────────────────────────────────────────────────
    def _on_close_request(self):
        """
        Close only the main RogueShield window.
        RSHost is an independent process – it is NOT terminated and
        continuous pop-ups keep running.
        """
        if self.config.has_password():
            if not self.security.require_password_for_exit():
                return
        # Do NOT stop RSHost. Only close this GUI.
        try:
            self.popup_mgr.cleanup()  # main window has no continuous engine
        except Exception:
            pass
        self.scanner.cancel()
        self.destroy()
        # RSHost keeps running → pop-ups continue → visible in Task Manager


def main():
    app = RogueShieldApp()
    app.mainloop()


if __name__ == "__main__":
    main()
