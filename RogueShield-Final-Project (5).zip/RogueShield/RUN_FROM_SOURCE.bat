@echo off
REM Run RogueShield directly from source (no build required)
cd /d "%~dp0"
echo Starting RogueShield from source...
python src\rogueshield.py
if errorlevel 1 (
    echo.
    echo If Python is not found, install Python 3.10+ from python.org
    echo and ensure "Add to PATH" is checked.
    pause
)
